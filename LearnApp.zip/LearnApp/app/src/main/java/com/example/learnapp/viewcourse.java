package com.example.learnapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class viewcourse extends AppCompatActivity {


    TextView text1,text2;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewcourse);

        text1 = findViewById(R.id.t1);
        text2 = findViewById(R.id.t2);

        Intent i = getIntent();
        String title = i.getStringExtra("title").toString();
        String text = i.getStringExtra("text").toString();

        text1.setText(title);
        text2.setText(text);
    }
}
