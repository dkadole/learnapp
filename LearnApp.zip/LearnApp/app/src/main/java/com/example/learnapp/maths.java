package com.example.learnapp;

public class maths {
    String id;
    String course;
    String title;
    String text;




}
